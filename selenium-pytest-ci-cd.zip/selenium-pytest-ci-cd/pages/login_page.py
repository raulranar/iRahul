class LoginPage:
    def __init__(self, driver):
        self.driver = driver
        self.username_field = "username_locator"
        self.password_field = "password_locator"
        self.login_button = "login_button_locator"

    def login(self, username, password):
        self.driver.find_element_by_id(self.username_field).send_keys(username)
        self.driver.find_element_by_id(self.password_field).send_keys(password)
        self.driver.find_element_by_id(self.login_button).click()
