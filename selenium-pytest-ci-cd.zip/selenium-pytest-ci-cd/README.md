# Selenium PyTest CI/CD Pipeline

This DevOps practice project automates test execution using Jenkins and Docker for a Python Selenium framework.

## 🔧 Tech Stack
- Python 3.9
- Selenium
- PyTest
- Jenkins (CI/CD)
- Docker
- HTML Report Generation

## 🧪 Run Tests Locally

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pytest --html=report.html --self-contained-html
```

## 📦 Run in Docker

```bash
docker build -t pytest-automation .
docker run pytest-automation
```
